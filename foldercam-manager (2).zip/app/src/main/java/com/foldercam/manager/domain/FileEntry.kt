package com.foldercam.manager.domain

data class FileEntry(
    val name: String,
    val path: String,
    val size: Long,
    val lastModified: Long,
    val isDirectory: Boolean,
    val type: String
)
