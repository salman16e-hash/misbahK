package com.foldercam.manager.ui.browser

import android.app.AlertDialog
import android.os.Bundle
import android.os.Environment
import android.view.*
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.foldercam.manager.domain.DirectFileManager
import com.foldercam.manager.domain.FileEntry
import com.foldercam.manager.databinding.FragmentBrowserBinding
import java.io.File

class FileBrowserFragment : Fragment() {
    private var _binding: FragmentBrowserBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var fileManager: DirectFileManager
    private lateinit var adapter: FileAdapter
    private var currentPath: String = Environment.getExternalStorageDirectory().absolutePath

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentBrowserBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fileManager = DirectFileManager(requireContext())
        setupRecyclerView()
        loadFiles(currentPath)

        binding.swipeRefresh.setOnRefreshListener { loadFiles(currentPath) }
    }

    private fun setupRecyclerView() {
        adapter = FileAdapter(
            onItemClick = { file ->
                if (file.isDirectory) {
                    currentPath = file.path
                    loadFiles(currentPath)
                } else {
                    // Open file logic
                }
            },
            onItemLongClick = { file -> showOptions(file) }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter
    }

    private fun loadFiles(path: String) {
        val files = fileManager.listFiles(path).sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
        adapter.submitList(files)
        binding.swipeRefresh.isRefreshing = false
    }

    private fun showOptions(file: FileEntry) {
        val options = arrayOf("Rename", "Delete", "Details")
        AlertDialog.Builder(requireContext())
            .setTitle(file.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showRenameDialog(file)
                    1 -> deleteFile(file)
                }
            }.show()
    }

    private fun showRenameDialog(file: FileEntry) {
        val input = EditText(requireContext())
        input.setText(file.name)
        AlertDialog.Builder(requireContext())
            .setTitle("Rename")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                if (fileManager.renameFile(file.path, input.text.toString())) loadFiles(currentPath)
            }.setNegativeButton("Cancel", null).show()
    }

    private fun deleteFile(file: FileEntry) {
        AlertDialog.Builder(requireContext())
            .setTitle("Confirm Delete")
            .setMessage("Are you sure you want to delete ${file.name}?")
            .setPositiveButton("Delete") { _, _ ->
                if (fileManager.deleteFile(file.path)) loadFiles(currentPath)
            }.setNegativeButton("Cancel", null).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
